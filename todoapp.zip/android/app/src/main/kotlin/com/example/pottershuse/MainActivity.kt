package com.example.pottershuse

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
